package com.hotel.test.hotelAPI;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.hotel.hotelAPI.entity.CustomerMaster;
import com.hotel.hotelAPI.repo.CustomerRepo;
import com.hotel.hotelAPI.repo.FacilitiesRepo;
import com.hotel.hotelAPI.repo.RoomRepo;

import com.hotel.hotelAPI.service.impl.HotelServiceImpl;



//import org.mockito.junit.jupiter.MockitoExtension;


@RunWith(MockitoJUnitRunner.class)
public class HotelServiceImplTest {
	
	
	@InjectMocks
	HotelServiceImpl hotelService;
	
	@Mock
	RoomRepo roomRepo;
	
	@Mock
	CustomerRepo customerRepo;
	
	@Mock
	FacilitiesRepo facilitiesRepo;
	
	@Before
	public void init() {
        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void getVacantRoomsTest() throws Exception {
		
		when(roomRepo.findVacantRoom()).thenReturn("2");		
		String count = hotelService.getVacantRooms();		
		assertEquals("2", count);
		
	}
		
	
	@Test
	public void getCustomerDetailsTest() throws Exception {
				
		CustomerMaster customerEntity = new CustomerMaster();
		
		customerEntity.setCustomerId(1);
		customerEntity.setName("Sathish");
		customerEntity.setAddress("Test Address");
		customerEntity.setAddressProof("PAN-XXX");
		customerEntity.setMobile("1234554321");
		customerEntity.setCheckInTime(new Timestamp(new Date().getTime()));
		customerEntity.setCheckOutTime(null);
		
		List<CustomerMaster> customerEntityList = new ArrayList<>();
		customerEntityList.add(customerEntity);
		
		Mockito.doReturn(customerEntityList).when(roomRepo).getCustomerByRoomNumber(101);
		CustomerMaster custEtyResult = (CustomerMaster)hotelService.getCustomerDetails("101");		
		assertEquals(1, custEtyResult.getCustomerId());
		assertEquals("Sathish", custEtyResult.getName());
		
	}
	
	
	
	@Test
	public void getAllCustomerDetailsTest() throws Exception {
		
		List<CustomerMaster> customerList = new ArrayList<>();
		
		CustomerMaster customerEntity = new CustomerMaster();
		
		customerEntity.setCustomerId(1);
		customerEntity.setName("Sathish");
		customerEntity.setAddress("Test Address");
		customerEntity.setAddressProof("PAN");
		customerEntity.setMobile("1234554321");
		customerEntity.setCheckInTime(new Timestamp(new Date().getTime()));
		customerEntity.setCheckOutTime(null);
		
		customerList.add(customerEntity);
		
		Mockito.doReturn(customerList).when(customerRepo).findAll();	
		
		List<CustomerMaster> resultCustList = hotelService.getAllCustomerDetails();
		CustomerMaster resultObj = resultCustList.get(0);
		assertEquals("Sathish", resultObj.getName());
		assertEquals("Test Address", resultObj.getAddress());
		assertEquals("PAN", resultObj.getAddressProof());
		assertEquals("1234554321", resultObj.getMobile());
		
	}
	
	@Test
	public void getFacilityDetailsTest() throws Exception {
		
		List<String> resultList = new ArrayList<>();
		resultList.add("TV");
		resultList.add("AC");
		Mockito.doReturn(1).when(roomRepo).findIdByRoomNumber(101);	
		Mockito.doReturn(resultList).when(facilitiesRepo).findFacilityByRoom(1);	
		
		resultList = (List<String>) hotelService.getFacilityDetails("101");		
		assertEquals("TV", resultList.get(0));
		assertEquals("AC", resultList.get(1));
		
	}
	
	@Test
	public void getRoomWithFacilityTest() throws Exception {
		
		List<String> resultList = new ArrayList<>();
		resultList.add("101");
		Mockito.doReturn(1).when(facilitiesRepo).findByName("TV");	
		Mockito.doReturn(resultList).when(facilitiesRepo).findRoomById(1);	
		
		resultList = (List<String>) hotelService.getRoomWithFacility("TV");		
		assertEquals("101", resultList.get(0));
		
	}

}
