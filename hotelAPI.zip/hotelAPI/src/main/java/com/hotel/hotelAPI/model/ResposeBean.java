package com.hotel.hotelAPI.model;

public class ResposeBean {
	
	//If the there is no exception status will be set to OK or else NOTOK
	private String status;
	//All the response will be mapped to Data as jsonString
	private String Data;
	//If any error the proper error message will be populated
	private String errMsg;
	
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getData() {
		return Data;
	}
	public void setData(String data) {
		Data = data;
	}
}
