package com.hotel.hotelAPI.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="ROOMMASTER")
public class RoomMaster {
	@Id
	@Column(name = "ROOMID")
	private Integer roomid;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "ROOMNUMBER")
	private Integer roomnumber;
	
	@Column(name = "PRICE")
	private Double price;
	
	@Column(name = "ISAVAILABLE")
	private Integer isavailable;
	
	@Column(name = "CUSTOMERID")
	private Integer customerid;

	public Integer getRoomid() {
		return roomid;
	}

	public void setRoomid(Integer roomid) {
		this.roomid = roomid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getRoomnumber() {
		return roomnumber;
	}

	public void setRoomnumber(Integer roomnumber) {
		this.roomnumber = roomnumber;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getIsavailable() {
		return isavailable;
	}

	public void setIsavailable(Integer isavailable) {
		this.isavailable = isavailable;
	}

	public Integer getCustomerid() {
		return customerid;
	}

	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}
	
	

}
