package com.hotel.hotelAPI.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hotel.hotelAPI.entity.RoomMaster;

@Repository
public interface RoomRepo extends JpaRepository<RoomMaster, Integer>{

	@Query("SELECT COUNT(*) FROM RoomMaster room WHERE room.isavailable = '1'")
	String findVacantRoom();
	
	@Query("SELECT room FROM RoomMaster room WHERE room.roomnumber = ?1")
	RoomMaster findByRoomNumber(Integer roomNumber);
	
	@Query(value = "SELECT C.* FROM CUSTOMERMASTER C,ROOMMASTER R WHERE R.ROOMNUMBER = ?1 AND R.CUSTOMERID = C.CUSTOMERID", 
			  nativeQuery = true)
	List<Object> getCustomerByRoomNumber(Integer roomNumber);
	
	@Query("SELECT room.roomid FROM RoomMaster room WHERE room.roomnumber = ?1")
	Integer findIdByRoomNumber(Integer roomNumber);
	
	


	
}
