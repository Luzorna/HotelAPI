package com.hotel.hotelAPI.service;

import java.util.List;
import com.hotel.hotelAPI.entity.CustomerMaster;
import com.hotel.hotelAPI.model.CustomerModel;
import com.hotel.hotelAPI.model.FacilitiesModel;

public interface HotelService {

	public String getVacantRooms() throws Exception;

	public CustomerMaster bookRoom(CustomerModel customer) throws Exception;

	public Object getCustomerDetails(String roomNumber) throws Exception;

	public List<CustomerMaster> getAllCustomerDetails() throws Exception;

	public List<String> getFacilityDetails(String roomNumber) throws Exception;

	public List<String> getRoomWithFacility(String facility) throws Exception;

	public List<FacilitiesModel> getRoomPriceWithFacility(String facility) throws Exception;

	public String generateCustomersRecord() throws Exception;
}
