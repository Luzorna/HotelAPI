package com.hotel.hotelAPI.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotel.hotelAPI.entity.CustomerMaster;

public interface CustomerRepo extends JpaRepository<CustomerMaster, Integer>{

}
