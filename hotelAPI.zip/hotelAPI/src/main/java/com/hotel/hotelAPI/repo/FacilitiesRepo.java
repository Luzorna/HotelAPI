package com.hotel.hotelAPI.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hotel.hotelAPI.entity.Facilities;

public interface FacilitiesRepo extends JpaRepository<Facilities, Integer>{

	@Query(value = "SELECT F.NAME FROM FACILITIES F,ROOMFACILITIES RF  WHERE RF.ROOMID = ?1 AND RF.FACILITYID = F.FACILITYID", 
			  nativeQuery = true)
	List<String> findFacilityByRoom(Integer roomId);
	
	@Query("SELECT F.facilityid FROM Facilities F WHERE F.name = ?1")
	Integer findByName(String name);
	
	
	@Query(value = "SELECT R.ROOMNUMBER FROM ROOMMASTER R WHERE R.ROOMID IN (SELECT ROOMID FROM ROOMFACILITIES WHERE FACILITYID = ?1) AND R.ISAVAILABLE = 1", 
			  nativeQuery = true)
	List<String> findRoomById(Integer facilityId);
	
	@Query(value = "SELECT R.ROOMNUMBER, R.PRICE FROM ROOMMASTER R WHERE R.ROOMID IN (SELECT ROOMID FROM ROOMFACILITIES WHERE FACILITYID = ?1)", 
			  nativeQuery = true)
	List<Object> findPriceByFacility(Integer facilityId);

}
