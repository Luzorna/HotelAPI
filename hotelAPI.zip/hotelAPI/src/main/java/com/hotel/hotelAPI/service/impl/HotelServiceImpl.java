package com.hotel.hotelAPI.service.impl;

import java.io.FileWriter;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hotel.hotelAPI.entity.CustomerMaster;
import com.hotel.hotelAPI.entity.RoomMaster;
import com.hotel.hotelAPI.model.CustomerModel;
import com.hotel.hotelAPI.model.FacilitiesModel;
import com.hotel.hotelAPI.repo.CustomerRepo;
import com.hotel.hotelAPI.repo.FacilitiesRepo;
import com.hotel.hotelAPI.repo.RoomRepo;
import com.hotel.hotelAPI.service.HotelService;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;

@Service
public class HotelServiceImpl implements HotelService{
	
	//Creating logger
	Logger log = (Logger) LogManager.getLogger(HotelServiceImpl.class);
	
	//Injecting Dependencies 
	@Autowired
	RoomRepo roomRepo;
	
	@Autowired
	CustomerRepo customerRepo;
	
	@Autowired
	FacilitiesRepo facilitiesRepo;
	
	/**
	 *This method will get all the rooms where isAvailable is 1 from roommaster table
	 */
	@Override
	public String getVacantRooms() throws Exception{
		String roomCount = "";
		
		roomCount = roomRepo.findVacantRoom();
		
		return roomCount;
	}
	
	/**
	 *This method will insert record to customermaster table and rollback if any error occurs
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public CustomerMaster bookRoom(CustomerModel customer) throws Exception{
	
		
		CustomerMaster customerEntity = new CustomerMaster();
		
		Timestamp checkInTime = new Timestamp(new Date().getTime());
				
		try {
			customerEntity.setName(customer.getName());
			customerEntity.setAddress(customer.getAddress());
			customerEntity.setAddressProof(customer.getAddressProof());
			customerEntity.setMobile(customer.getMobile());
			customerEntity.setCheckInTime(checkInTime);
			customerEntity.setCheckOutTime(null);
			
			//Insert data into customer table
			customerEntity = customerRepo.save(customerEntity);
			Integer customerId = customerEntity.getCustomerId();
			
			//Get room details entity by roomnumber
			RoomMaster room= roomRepo.findByRoomNumber(Integer.parseInt(customer.getRoomNumber()));		
			//update the customerid in roommaster entity
			room.setCustomerid(customerId);
			//set isAvailable as 0
			room.setIsavailable(0);
			
			roomRepo.save(room);
		}
		catch (Exception e) {
			log.error("Error while booking room for customer: " + customer.getName() + "Rolling back with Error: " +e.getMessage());
		}
				
		return customerEntity;
	}
	
	/**
	 *This method will get the details of customer in given room nummber
	 */
	@Override
	public Object getCustomerDetails(String roomNumber) throws Exception{
		
		List<Object> customersList = new ArrayList<>();
		try {
			customersList = roomRepo.getCustomerByRoomNumber(Integer.parseInt(roomNumber));			

		}
		catch (Exception e) {
			log.error("Error in getCustomerDetails in room : " + roomNumber + " Error: " +e.getMessage());
		}
			
		return customersList.get(0);
	}
	
	/**
	 *This method will get the details of All customer in given in the Hotel
	 */
	@Override
	public List<CustomerMaster> getAllCustomerDetails() throws Exception {

		List<CustomerMaster> CustomerList = null;
		
		CustomerList = customerRepo.findAll();
			
		return CustomerList;
	}
	
	/**
	 *This method will get the Facilities available in given room from ROOMFACILITIES table
	 */
	@Override
	public List<String> getFacilityDetails(String roomNumber) throws Exception{
		
		Integer roomId = roomRepo.findIdByRoomNumber(Integer.parseInt(roomNumber));	
		List<String> resultList = null;
		
		resultList = facilitiesRepo.findFacilityByRoom(roomId);
		
		
		return resultList;
	}
	
	/**
	 *This method will get the Room with specified facility using ROOMFACILITIES table
	 */
	@Override
	public List<String> getRoomWithFacility(String facility) throws Exception{
		List<String> resultList = null;
			
		Integer facilityId = facilitiesRepo.findByName(facility);
		log.info("Getting room with facilityId :" + facilityId);
		resultList = facilitiesRepo.findRoomById(facilityId);

		return resultList;
	}
	
	/**
	 *This method will get the Room Price with specified facility from table
	 */
	@Override
	public List<FacilitiesModel> getRoomPriceWithFacility(String facility) throws Exception{
		
		List<FacilitiesModel> priceList = new ArrayList<>();
        
		Integer facilityId = facilitiesRepo.findByName(facility);
		log.info("Getting room price with facilityId :" + facilityId);
		List<Object> objList = facilitiesRepo.findPriceByFacility(facilityId);

		for (Object object : objList) {
			FacilitiesModel roomPrice = new FacilitiesModel();
			Object[] obj = (Object [])object;
			roomPrice.setRoomNumber((Integer)obj[0]);
			roomPrice.setPrice((BigDecimal) obj[1]);
			priceList.add(roomPrice);
		}
		
		return priceList;
	}
	
	/**
	 *This method will generate customer details in CSV file  using opencsv jar
	 */
	@Override
	public String generateCustomersRecord() throws Exception{
		
		// name of generated csv
        final String CSV_LOCATION = "CustomerDetails.csv ";
        
		List<CustomerMaster> customerList = customerRepo.findAll();
		List<CustomerModel> custDetailList = new ArrayList<CustomerModel>();
		
		for (CustomerMaster customerMaster : customerList) {
			CustomerModel customer = new CustomerModel();
			customer.setAddress(customerMaster.getAddress());
			customer.setAddressProof(customerMaster.getAddressProof());
			customer.setCheckInTime(customerMaster.getCheckInTime());
			customer.setCheckOutTime(customerMaster.getCheckOutTime());
			customer.setMobile(customerMaster.getMobile());
			customer.setName(customerMaster.getName());
		
			custDetailList.add(customer);
		}
	
		// Creating writer class to generate
		// csv file
   
		FileWriter writer = new FileWriter(CSV_LOCATION);
		// Create Mapping Strategy to arrange the 
        // column name in order
        ColumnPositionMappingStrategy<CustomerModel> mappingStrategy = new ColumnPositionMappingStrategy<CustomerModel>();
        mappingStrategy.setType(CustomerModel.class);
  
        // Create column name as provided in below.
        String[] columns = new String[]  { "name", "address", "addressProof", "mobile", "checkInTime", "checkOutTime", "roomNumber"};
        mappingStrategy.setColumnMapping(columns);
		
		// Creating StatefulBeanToCsv object
        StatefulBeanToCsvBuilder<CustomerModel> builder=new StatefulBeanToCsvBuilder<CustomerModel>(writer);
        StatefulBeanToCsv<CustomerModel> beanWriter = builder.withMappingStrategy(mappingStrategy).build();
  
        // Write list to StatefulBeanToCsv object
        beanWriter.write(custDetailList);
  
        // closing the writer object
        writer.close();
				
		return CSV_LOCATION;
	}

}
