package com.hotel.hotelAPI.model;

import java.sql.Timestamp;

public class CustomerModel {
	
	public CustomerModel() {
		
	}
	  
	public CustomerModel(String name, String address, String addressProof, String mobile, Timestamp checkInTime,
			Timestamp checkOutTime, String roomNumber) {
		super();
		this.name = name;
		this.address = address;
		this.addressProof = addressProof;
		this.mobile = mobile;
		this.checkInTime = checkInTime;
		this.checkOutTime = checkOutTime;
		this.roomNumber = roomNumber;
	}

	private String name;
	
	private String address;
	
	private String addressProof;
	
	private String mobile;
	
	private Timestamp checkInTime;
	
	private Timestamp checkOutTime;
	
	private String roomNumber;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddressProof() {
		return addressProof;
	}

	public void setAddressProof(String addressProof) {
		this.addressProof = addressProof;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public Timestamp getCheckOutTime() {
		return checkOutTime;
	}

	public void setCheckOutTime(Timestamp checkOutTime) {
		this.checkOutTime = checkOutTime;
	}

	public Timestamp getCheckInTime() {
		return checkInTime;
	}

	public void setCheckInTime(Timestamp checkInTime) {
		this.checkInTime = checkInTime;
	}

	@Override
	public String toString() {
		return "CustomerModel [name=" + name + ", address=" + address + ", addressProof=" + addressProof + ", mobile="
				+ mobile + ", checkInTime=" + checkInTime + ", checkOutTime=" + checkOutTime + ", roomNumber="
				+ roomNumber + "]";
	}
	
}
