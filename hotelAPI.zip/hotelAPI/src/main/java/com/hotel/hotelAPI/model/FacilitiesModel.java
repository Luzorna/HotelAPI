package com.hotel.hotelAPI.model;

import java.math.BigDecimal;

public class FacilitiesModel {
	
	private Integer roomNumber;
	private BigDecimal price;
	
	public Integer getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(Integer roomNumber) {
		this.roomNumber = roomNumber;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	

}
