package com.hotel.hotelAPI.controller;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.google.gson.Gson;
import com.hotel.hotelAPI.model.CustomerModel;
import com.hotel.hotelAPI.model.ResposeBean;
import com.hotel.hotelAPI.service.HotelService;

/**
 * This API will help to query rooms availability, price,
 * facilities information from the hotel and also can book the hotel. 
 * This will also allow the hotel owners to find the number of vacant rooms, 
 * customer details who booked the hotel.
 */
@RestController
@RequestMapping("HotelService")
public class HotelController {
	
	Logger log = (Logger) LogManager.getLogger(HotelController.class);
	
	@Autowired
	HotelService hotelService;
	
	/**
	 * @param null
	 * @return Long - number of vacant rooms
	 * This method will find the vacant rooms available in RoomMaster table
	 */
	@GetMapping("/vacantRooms")
	@ResponseBody
	public ResponseEntity<ResposeBean> getVacantRooms(){
		log.info("Getting available rooms");
		
		ResposeBean response = new ResposeBean();
		try {
			response.setData(hotelService.getVacantRooms());
			response.setStatus("OK");
		}
		catch (Exception e) {
			log.error(e.getMessage());
			response.setErrMsg("Error occured while getting vacant rooms please try again");
			response.setStatus("NOTOK");
		}
		
		return  new ResponseEntity<ResposeBean>(response, HttpStatus.OK);
		
	}
	
	
	/**
	 * @param Customer Entity -> (name,address,addressProof,mobile,roomNumber)
	 * @return Integer - CustomerId
	 * This method will store customer information CustomerMaster table
	 */
	@PostMapping("/bookRooms")
	@ResponseBody
	public ResponseEntity<ResposeBean> bookRoom(@RequestBody CustomerModel customer){
		log.info("Booking room");
		
		ResposeBean response = new ResposeBean();
		try { 
			response.setData("CustomerId : " + hotelService.bookRoom(customer).getCustomerId());
			response.setStatus("OK");
		}
		catch (Exception e) {
			log.error(e.getMessage());
			response.setErrMsg("Error occured while booking room : " + customer.getRoomNumber() 
			+" for Customer : " + customer.getName());
			response.setStatus("NOTOK");
			return  new ResponseEntity<ResposeBean>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return  new ResponseEntity<ResposeBean>(response, HttpStatus.OK);
		
	}
	
	/**
	 * @param roomNumber
	 * @return Customer Details of the requested room
	 * This method will find the vacant rooms available in RoomMaster table
	 */
	@GetMapping("/getCustomerInRoom/{roomNumber}")
	@ResponseBody
	public ResponseEntity<ResposeBean> getCustomerInRoom(@PathVariable String roomNumber){
		log.info("Getting customer from room : " + roomNumber);
		
		ResposeBean response = new ResposeBean();
		try {
			response.setData(new Gson().toJson(hotelService.getCustomerDetails(roomNumber)));
			response.setStatus("OK");
		}
		catch (Exception e) {
			log.error(e.getMessage());
			response.setErrMsg("Error occured while getting customer details of room : " + roomNumber);
			response.setStatus("NOTOK");
		}
		
		return  new ResponseEntity<ResposeBean>(response, HttpStatus.OK);
		
	}
	
	
	/**
	 * @param null
	 * @return Long - number of vacant rooms
	 * This method will get all the customers in Hotel
	 */
	@GetMapping("/getAllCustomerInHotel")
	@ResponseBody
	public ResponseEntity<ResposeBean> getAllCustomerInHotel(){
		log.info("Getting customers in Hotel" );
		
		ResposeBean response = new ResposeBean();
		try {
			response.setData(new Gson().toJson(hotelService.getAllCustomerDetails()));
			response.setStatus("OK");
		}
		catch (Exception e) {
			log.error(e.getMessage());
			response.setErrMsg("Error occured please try again");
			response.setStatus("NOTOK");
		}
		
		return  new ResponseEntity<ResposeBean>(response, HttpStatus.OK);
		
	}
	
	/**
	 * @param roomNumber
	 * @return Facilities available in the requested room
	 * This method will find the facilities of given roomNumber
	 */
	@GetMapping("/getFacilitiesInRoom/{roomNumber}")
	@ResponseBody
	public ResponseEntity<ResposeBean> getFacilitiesInRoom(@PathVariable String roomNumber){
		log.info("Getting Facilities of room : " + roomNumber);
		
		ResposeBean response = new ResposeBean();
		try {
			response.setData(new Gson().toJson(hotelService.getFacilityDetails(roomNumber)));
			response.setStatus("OK");
		}
		catch (Exception e) {
			log.error(e.getMessage());
			response.setData("Error occured please try again");
			response.setStatus("NOTOK");
		}
		
		return  new ResponseEntity<ResposeBean>(response, HttpStatus.OK);
		
	}
	
	/**
	 * @param Facility name
	 * @return Available room with specified criteria 
	 * 
	 */
	@GetMapping("/getRoomWithFacility/{facility}")
	@ResponseBody
	public ResponseEntity<ResposeBean> getRoomWithFacility(@PathVariable String facility){
		log.info("Getting Room with Facility : " + facility);
		
		ResposeBean response = new ResposeBean();
		try {
			
			List<String> roomList = hotelService.getRoomWithFacility(facility);
			if(roomList.size()>0) {
				log.info("No rooms available with Facility : "+ facility);
			}
			response.setData(new Gson().toJson(roomList));
			response.setStatus("OK");
		}
		catch (Exception e) {
			log.error(e.getMessage());
			response.setData("Error occured please try again");
			response.setStatus("NOTOK");
		}
		
		return  new ResponseEntity<ResposeBean>(response, HttpStatus.OK);
		
	}
	
	
	/**
	 * @param Facility name
	 * @return Room price with specified criteria 
	 * 
	 */
	@GetMapping("/getRoomPriceWithFacility/{facility}")
	@ResponseBody
	public ResponseEntity<ResposeBean> getRoomPriceWithFacility(@PathVariable String facility){
		log.info("Getting Room price with Facility : " + facility);
		
		ResposeBean response = new ResposeBean();
		try {
			response.setData(new Gson().toJson(hotelService.getRoomPriceWithFacility(facility)));
			response.setStatus("OK");
		}
		catch (Exception e) {
			log.error(e.getMessage());
			response.setData("Error occured please try again");
			response.setStatus("NOTOK");
		}
		
		return  new ResponseEntity<ResposeBean>(response, HttpStatus.OK);
		
	}
	
	
	/**
	 * @param Facility name
	 * @return Create a csv file with customer details 
	 * 
	 */
	@GetMapping("/generateCustomersRecord")
	@ResponseBody
	public ResponseEntity<ResposeBean> generateCustomersRecord(){
		log.info("Generating Custromer Record");
		
		ResposeBean response = new ResposeBean();
		try {
			
			response.setData(hotelService.generateCustomersRecord());
			response.setStatus("OK");
		}
		catch (Exception e) {
			log.error(e.getMessage());
			response.setData("Error occured please try again");
			response.setStatus("NOTOK");
		}
		
		return  new ResponseEntity<ResposeBean>(response, HttpStatus.OK);
		
	}
}
